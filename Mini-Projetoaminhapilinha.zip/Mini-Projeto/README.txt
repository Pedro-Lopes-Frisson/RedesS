Project: 'Projeto 1' created on 2021-01-26
Author: John Doe <john.doe@example.com>

No project description was given